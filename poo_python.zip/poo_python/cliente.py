class cliente:
    #METODO CONTRUCTOR
    def_init_(self): # type: ignore
    self.nombre=""
    self.apellido=""
    self.cedula=""


    #metodo basico
    def set_nombre(self,dato_nombre):
        self.nombre=dato_nombre

    def get_nombre(self):
        return self.nombre
    def pagar(self):
        return"cliente no tiene efectivo"