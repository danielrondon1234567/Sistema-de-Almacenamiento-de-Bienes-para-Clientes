class animal:
  #metodo contrutor
def_init_(self,dato_tamaño,dato_edad,dato_raza): # type: ignore
   #atributos
self.tamaño=dato_tamaño
self.edad=dato_edad
self.raza=dato_raza
self.estado=self.llorar()#####





#metodo basicos
def llorar():
    mensaje="animal llorando..."
    print(mensaje)

def comer(self):
    mensaje="animal comiendo"
    return mensaje
    

def dormir(self):
    mensaje="animal dormir"
    return mensaje

def imprimir_info(self):
    mensaje="tamaño" + self.tamaño +"raza: " + self.raza+"edad: " + self.edad