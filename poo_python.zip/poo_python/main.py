from animal import animal
from cliente import cliente

perro=animal("pequeño","2 años", "labrador")
aux_accion=perro.comer()
print(aux_accion)

perro.imprimir_info()

objcliente=cliente()
dato_nombre=objcliente.get_nombre()
print(dato_nombre)
objcliente.set_nombre("nelson")
print(objcliente.get_nombre())